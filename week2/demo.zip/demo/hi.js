document.getElementsByTagName(h1)[0].innerHTML = "Hello"
